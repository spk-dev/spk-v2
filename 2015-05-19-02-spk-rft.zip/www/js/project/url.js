/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



var urlAjax = "ajax.php";

var urlEvenements = "../rest/evenements";
var urlEvenement = "../rest/evenement/";
var urlOrganisateurs = "../rest/organisateurs";
var urlOrganisateursResume = "../rest/organisateursresume";
var urlOrganisateursNextEvent = "../rest/organisateursprochainevenement";
var urlOrganisateur = "../rest/organisateur/";
var urlNbEvenementParThemes = "../rest/nbevenementsparthemes";
var urlThemes = "../rest/themes/";
var urlTypesOrganisateur = "../rest/typesOrganisateur/";
var urlTypesEvenement = "../rest/typesevenement/";
var urlMarqueur = 'http://www.spibook.com/images/spibook/gmarkers/spibook.png';