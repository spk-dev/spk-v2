
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header"><i class="fa  fa-envelope"></i>Messagerie </h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!--<div class="row">-->

<hr/>

    



<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="heading1">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#mail1" aria-expanded="true" aria-controls="mail1">
          Message de : EMETTEUR DU MESSAGE -  15/06/2015 11h24
        </a>
      </h4>
    </div>
    <div id="mail1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading1">
      <div class="panel-body">
         Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet imperdiet nisl, id tempus nibh. Donec molestie sem odio, id pharetra enim rhoncus vel. Nullam a mi lacinia dui bibendum venenatis non ut ligula. Donec interdum sem in dapibus malesuada. Cras gravida aliquet neque vitae interdum. Aliquam tincidunt finibus ante, eu suscipit nulla pharetra sollicitudin. Fusce auctor accumsan augue, quis varius arcu. Praesent viverra tincidunt ornare. Nullam arcu turpis, gravida et urna a, interdum volutpat lorem. Nunc imperdiet vestibulum est, sit amet dignissim neque tristique eget. Maecenas aliquet faucibus nulla non rhoncus. Phasellus convallis magna a elit rutrum feugiat.
        In vestibulum hendrerit libero aliquam tincidunt. Aliquam erat volutpat. Phasellus fringilla in neque vitae pretium. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras vitae sapien eu tortor viverra tempus. Morbi porta purus ut ante commodo, vitae finibus felis fringilla. Phasellus pellentesque odio tincidunt odio ornare porta. Cras ac augue sit amet tellus varius consequat. Maecenas eleifend sem vel suscipit auctor. Sed feugiat mauris vel felis vehicula, non pellentesque lectus pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae;
        Maecenas ut purus quis felis blandit malesuada. Cras at urna mollis nisl dapibus feugiat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam consequat ultrices nibh, at convallis metus. Proin ut ipsum est. Nullam tristique vel metus vel faucibus. Aenean sit amet varius lectus. Praesent interdum, ligula quis malesuada tempus, enim nulla placerat magna, ac posuere nibh enim a orci. Fusce ut lectus turpis. Nulla varius purus sed massa bibendum blandit.
        Donec neque lacus, eleifend ac tristique ut, sodales ac erat. Quisque non tellus ut nisi ultricies tempus. Nunc commodo bibendum urna a gravida. Curabitur pulvinar, odio vitae rutrum dictum, odio est bibendum ligula, sit amet placerat diam nulla eget quam. Cras scelerisque nisi at ipsum tincidunt dictum. Duis tortor eros, faucibus id odio eget, semper ornare sem. Etiam quam odio, pharetra sit amet finibus non, lacinia sit amet nisl. Donec justo velit, sollicitudin eget orci ac, rutrum pretium nunc. Suspendisse ipsum ligula, vehicula non lectus sit amet, ornare vestibulum metus. Quisque rutrum venenatis orci eu imperdiet.
        Pellentesque faucibus ipsum et erat venenatis sagittis. Integer sodales tortor eu blandit aliquam. Pellentesque varius libero vitae commodo finibus. Donec felis diam, pellentesque sit amet diam sit amet, semper lacinia tellus. Quisque a ipsum eget nunc facilisis hendrerit. Donec arcu elit, efficitur sit amet velit eu, elementum tincidunt orci. Ut ex dolor, gravida eget imperdiet eget, accumsan eu leo.
   </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="heading2">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#mail2" aria-expanded="false" aria-controls="mail2">
          Réponse envoyé le 02/07/2015 à 12:05 
        </a>
      </h4>
    </div>
    <div id="mail2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading2">
      <div class="panel-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="heading3">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#mail3" aria-expanded="false" aria-controls="mail3">
          Message reçu le 04/07/2015 à 15:15 
        </a>
      </h4>
    </div>
    <div id="mail3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
      <div class="panel-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div>
  
</div>























<hr/>
<div class="container-fluid">
    <label for="contact">Répondre</label>
    <textarea class="form-control" rows="3"></textarea>
    <button class="btn">Envoyer</button>
    </div>
    
    <hr/>
<!--</div>-->
   
    